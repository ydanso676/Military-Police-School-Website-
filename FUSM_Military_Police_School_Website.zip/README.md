# FUSM Military Police School Website

A responsive starter website inspired by a traditional military academy layout.

## Files
- `index.html` — all page sections and content
- `style.css` — layout, colors, responsive design
- `script.js` — mobile navigation

## Publish free with GitHub Pages
1. Create a GitHub repository named `fusm-military-police-school`.
2. Upload these three files to the repository's main/root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site; the public URL will appear in Settings → Pages.

## Customize before publishing
Replace sample news, course descriptions, rank placeholders, leadership names, and application information with approved FUSM information. Add official links where marked. The website is a static information site; it does not collect applications or store exam scores.
