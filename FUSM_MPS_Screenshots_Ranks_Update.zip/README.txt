FUSM Military Police School website.
Upload index.html, style.css, and script.js to the root of your GitHub Pages repository.
The rank pages reproduce the supplied screenshot wording; insignia tiles are editable placeholders.
